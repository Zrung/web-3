
import React from 'react';
import { Screen } from '../types';

interface BottomNavProps {
  current: Screen;
  navigateTo: (screen: Screen) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ current, navigateTo }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 backdrop-blur-lg border-t border-gray-100 px-4 pt-3 pb-8 flex justify-between items-center z-50">
      <button 
        onClick={() => navigateTo(Screen.HOME)}
        className={`flex flex-col items-center gap-1 flex-1 ${current === Screen.HOME ? 'text-primary' : 'text-charcoal/40'}`}
      >
        <span className={`material-symbols-outlined text-[26px] ${current === Screen.HOME ? 'fill-[1]' : ''}`}>home</span>
        <span className="text-[9px] font-bold uppercase tracking-tighter">Trang chủ</span>
      </button>
      <button 
        onClick={() => navigateTo(Screen.LISTING)}
        className={`flex flex-col items-center gap-1 flex-1 ${current === Screen.LISTING ? 'text-primary' : 'text-charcoal/40'}`}
      >
        <span className="material-symbols-outlined text-[26px]">search</span>
        <span className="text-[9px] font-bold uppercase tracking-tighter">Tìm kiếm</span>
      </button>
      <button 
        onClick={() => navigateTo(Screen.DASHBOARD)}
        className={`flex flex-col items-center gap-1 flex-1 ${current === Screen.DASHBOARD ? 'text-primary' : 'text-charcoal/40'}`}
      >
        <span className={`material-symbols-outlined text-[26px] ${current === Screen.DASHBOARD ? 'fill-[1]' : ''}`}>dashboard</span>
        <span className="text-[9px] font-bold uppercase tracking-tighter">Bảng tin</span>
      </button>
      <button 
        onClick={() => navigateTo(Screen.CART)}
        className={`flex flex-col items-center gap-1 flex-1 ${current === Screen.CART ? 'text-primary' : 'text-charcoal/40'}`}
      >
        <span className="material-symbols-outlined text-[26px]">shopping_cart</span>
        <span className="text-[9px] font-bold uppercase tracking-tighter">Giỏ hàng</span>
      </button>
      <button 
        onClick={() => navigateTo(Screen.PROFILE)}
        className={`flex flex-col items-center gap-1 flex-1 ${current === Screen.PROFILE ? 'text-primary' : 'text-charcoal/40'}`}
      >
        <span className={`material-symbols-outlined text-[26px] ${current === Screen.PROFILE ? 'fill-[1]' : ''}`}>person</span>
        <span className="text-[9px] font-bold uppercase tracking-tighter">Hồ sơ</span>
      </button>
    </nav>
  );
};

export default BottomNav;
