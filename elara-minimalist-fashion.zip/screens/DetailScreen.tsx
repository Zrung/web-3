
import React, { useState } from 'react';
import { Screen, Product } from '../types';
import BottomNav from '../components/BottomNav';

interface DetailScreenProps {
  product: Product;
  navigateTo: (screen: Screen, product?: Product) => void;
  addToCart: (product: Product, size: string, color: string) => void;
}

const DetailScreen: React.FC<DetailScreenProps> = ({ product, navigateTo, addToCart }) => {
  const [selectedSize, setSelectedSize] = useState(product.variants?.[1] || 'M');
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0] || 'Cát');
  const [showToast, setShowToast] = useState(false);

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
      navigateTo(Screen.CART);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background-light pb-32">
      {/* Toast Notification */}
      <div className={`fixed top-6 left-4 right-4 z-[100] bg-white shadow-2xl rounded-2xl p-4 flex items-center gap-4 border border-black/5 transition-all duration-300 transform ${showToast ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'}`}>
        <div className="size-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
          <span className="material-symbols-outlined">check_circle</span>
        </div>
        <div className="flex-1">
          <p className="font-bold text-sm">Đã thêm vào giỏ hàng</p>
          <p className="text-xs text-gray-500">{product.name}</p>
        </div>
      </div>

      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-4 bg-white/80 backdrop-blur-md">
        <button 
          onClick={() => navigateTo(Screen.LISTING)}
          className="flex items-center justify-center size-10 rounded-full bg-white shadow-sm"
        >
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <div className="flex gap-2">
          <button className="flex items-center justify-center size-10 rounded-full bg-white shadow-sm">
            <span className="material-symbols-outlined">share</span>
          </button>
          <button className="flex items-center justify-center size-10 rounded-full bg-white shadow-sm">
            <span className="material-symbols-outlined">favorite</span>
          </button>
        </div>
      </nav>

      <main>
        <div className="relative w-full aspect-[4/5] overflow-hidden">
          <div className="flex h-full w-full overflow-x-auto snap-x snap-mandatory no-scrollbar">
            <div 
              className="shrink-0 w-full h-full snap-center bg-cover bg-center" 
              style={{ backgroundImage: `url("${product.image}")` }}
            />
          </div>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            <div className="h-1 w-8 bg-white rounded-full"></div>
            <div className="h-1 w-8 bg-white/40 rounded-full"></div>
            <div className="h-1 w-8 bg-white/40 rounded-full"></div>
          </div>
        </div>

        <section className="px-6 pt-8">
          <div className="flex justify-between items-start mb-2">
            <h1 className="text-3xl font-bold tracking-tight leading-tight max-w-[70%]">{product.name}</h1>
            <p className="text-2xl font-semibold text-primary">{product.price.toFixed(2)} $</p>
          </div>
          <div className="flex items-center gap-4 mt-2">
            <div className="flex items-center">
              <span className="material-symbols-outlined text-primary text-lg fill-[1]">star</span>
              <span className="ml-1 font-bold">{product.rating}</span>
            </div>
            <span className="text-sm text-gray-500">{product.reviewsCount} đánh giá</span>
            <span className="h-4 w-[1px] bg-gray-200"></span>
            <span className="text-xs font-bold uppercase tracking-widest text-green-700">Còn hàng</span>
          </div>
        </section>

        <section className="px-6 mt-10">
          <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-4">Chọn màu sắc: <span className="text-charcoal">{selectedColor}</span></p>
          <div className="flex gap-4">
            {product.colors?.map(color => (
              <button 
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`size-12 rounded-full border border-black/5 transition-all ${selectedColor === color ? 'ring-2 ring-primary ring-offset-4' : ''}`}
                style={{ backgroundColor: color === 'Cát' ? '#E6DCCF' : color === 'Than' ? '#343434' : color === 'Rêu' ? '#5E6252' : color === 'Be' ? '#f5f5dc' : color === 'Trắng' ? '#ffffff' : color === 'Xanh Navy' ? '#000080' : color === 'Đen' ? '#000000' : '#cccccc' }}
              />
            ))}
          </div>
        </section>

        <section className="px-6 mt-10">
          <div className="flex justify-between items-center mb-4">
            <p className="text-xs font-bold uppercase tracking-widest text-gray-400">Chọn kích thước</p>
            <button className="text-xs font-bold underline">Hướng dẫn chọn size</button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {product.variants?.map(size => (
              <button 
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`h-12 flex items-center justify-center rounded-lg transition-all border ${selectedSize === size ? 'border-2 border-primary bg-primary/10 font-bold' : 'border-gray-200 bg-white'}`}
              >
                {size}
              </button>
            ))}
          </div>
        </section>

        <section className="px-6 mt-12 space-y-6">
          <div className="p-6 rounded-xl bg-rich-beige">
            <h3 className="font-bold text-lg mb-2">Ghi chú biên tập</h3>
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
          </div>
          
          <div className="border-t border-gray-200 pt-4">
            <div className="flex justify-between items-center py-2">
              <span className="font-bold">Chất liệu & Bảo quản</span>
              <span className="material-symbols-outlined">expand_more</span>
            </div>
            <div className="flex gap-6 mt-4 text-gray-500">
              <div className="flex flex-col items-center gap-1">
                <span className="material-symbols-outlined">dry_cleaning</span>
                <span className="text-[10px] font-bold uppercase">Giặt khô</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="material-symbols-outlined">iron</span>
                <span className="text-[10px] font-bold uppercase">Ủi nhiệt thấp</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="material-symbols-outlined">eco</span>
                <span className="text-[10px] font-bold uppercase">100% Linen</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white/90 backdrop-blur-xl border-t border-gray-100 z-[60]">
        <div className="max-w-md mx-auto flex gap-4">
          <button 
            onClick={handleAddToCart}
            className="w-full h-14 bg-primary text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-primary/20 active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined">shopping_bag</span>
            Thêm vào giỏ hàng
          </button>
        </div>
      </div>
    </div>
  );
};

export default DetailScreen;
