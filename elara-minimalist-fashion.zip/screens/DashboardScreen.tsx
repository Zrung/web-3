
import React from 'react';
import { Screen } from '../types';
import BottomNav from '../components/BottomNav';

interface DashboardScreenProps {
  navigateTo: (screen: Screen) => void;
}

const DashboardScreen: React.FC<DashboardScreenProps> = ({ navigateTo }) => {
  // Dữ liệu giả lập tinh chỉnh cho trực quan
  const revenueSegments = [
    { label: 'Direct', value: 45, color: '#e0775c', dash: '45 100', offset: '0' },
    { label: 'Social', value: 35, color: '#2c2c2c', dash: '35 100', offset: '-45' },
    { label: 'Ads', value: 20, color: '#d1cfc7', dash: '20 100', offset: '-80' },
  ];

  const inventoryStats = [
    { label: 'Nam', qty: 420, height: '60%' },
    { label: 'Nữ', qty: 580, height: '90%' },
    { label: 'Phụ kiện', qty: 240, height: '40%' },
  ];

  const aovTrend = [
    { m: 'T9', v: 175, h: '65%' },
    { m: 'T10', v: 190, h: '80%' },
    { m: 'T11', v: 215, h: '100%' },
  ];

  return (
    <div className="min-h-screen bg-background-light pb-36">
      {/* Header Tối giản */}
      <header className="px-6 pt-10 pb-6 flex items-end justify-between">
        <div>
          <p className="text-[10px] font-black text-primary uppercase tracking-[0.3em] mb-1">Business Insight</p>
          <h1 className="text-4xl font-black text-charcoal tracking-tighter">Bảng tin.</h1>
        </div>
        <button 
          onClick={() => navigateTo(Screen.ANALYTICS)}
          className="size-14 rounded-[22px] bg-white shadow-xl shadow-black/5 border border-gray-50 flex items-center justify-center text-charcoal active:scale-90 transition-all"
        >
          <span className="material-symbols-outlined text-2xl">grid_view</span>
        </button>
      </header>

      <main className="px-4 space-y-4">
        {/* Bento Grid Row 1: Tổng doanh thu (Full Width) */}
        <section className="bg-charcoal rounded-[45px] p-8 text-white relative overflow-hidden shadow-2xl shadow-charcoal/20">
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-10">
              <div className="size-12 rounded-2xl bg-white/10 flex items-center justify-center">
                <span className="material-symbols-outlined text-primary">account_balance_wallet</span>
              </div>
              <span className="px-3 py-1 bg-green-500/20 text-green-400 text-[10px] font-bold rounded-full border border-green-500/30">
                +12.5% UP
              </span>
            </div>
            <p className="text-white/40 text-[11px] font-bold uppercase tracking-widest mb-1">Doanh thu thuần (Tháng 11)</p>
            <h2 className="text-4xl font-black tracking-tighter">$124,500</h2>
          </div>
          {/* Decorative element */}
          <div className="absolute -bottom-10 -right-10 size-48 bg-primary/20 rounded-full blur-[60px]"></div>
        </section>

        {/* Bento Grid Row 2: 2 Columns */}
        <div className="grid grid-cols-2 gap-4">
          {/* Doanh thu - Biểu đồ tròn */}
          <div className="bg-white rounded-[40px] p-6 border border-gray-100 shadow-sm flex flex-col items-center">
            <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-6 w-full text-left">Nguồn thu</h3>
            <div className="relative size-24 mb-6">
              <svg viewBox="0 0 32 32" className="size-full -rotate-90">
                {revenueSegments.map((item, idx) => (
                  <circle
                    key={idx}
                    r="16"
                    cx="16"
                    cy="16"
                    fill="transparent"
                    stroke={item.color}
                    strokeWidth="32"
                    strokeDasharray={item.dash}
                    strokeDashoffset={item.offset}
                    className="transition-all duration-1000"
                  />
                ))}
              </svg>
              <div className="absolute inset-4 bg-white rounded-full border border-gray-50 flex items-center justify-center">
                <span className="text-[8px] font-black text-charcoal">75% DIGI</span>
              </div>
            </div>
            <div className="w-full space-y-2">
              {revenueSegments.map((s, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="size-1.5 rounded-full" style={{ backgroundColor: s.color }} />
                    <span className="text-[9px] font-bold text-gray-400">{s.label}</span>
                  </div>
                  <span className="text-[9px] font-black text-charcoal">{s.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* AOV - Biểu đồ cột nhỏ */}
          <div className="bg-rich-beige/30 rounded-[40px] p-6 border border-gray-100 shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Chỉ số AOV</h3>
              <p className="text-2xl font-black text-primary">$215</p>
              <p className="text-[8px] font-bold text-green-600">TĂNG TRƯỞNG MẠNH</p>
            </div>
            <div className="flex items-end justify-between h-20 gap-2 mt-4">
              {aovTrend.map((item, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5">
                  <div 
                    className={`w-full rounded-t-lg transition-all duration-1000 ${idx === 2 ? 'bg-primary shadow-lg shadow-primary/20' : 'bg-primary/20'}`}
                    style={{ height: item.h }}
                  />
                  <span className="text-[8px] font-bold text-gray-400">{item.m}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bento Grid Row 3: Inventory (Full Width) */}
        <section className="bg-white rounded-[40px] p-8 border border-gray-100 shadow-sm">
          <div className="flex justify-between items-center mb-10">
            <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <span className="material-symbols-outlined text-sm text-primary">inventory</span>
              Kho hàng & Phân phối
            </h3>
            <span className="text-[10px] font-black text-charcoal">1,240 PCS TOTAL</span>
          </div>
          <div className="flex items-end justify-between h-32 gap-8 px-4">
            {inventoryStats.map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-4 group">
                <div className="relative w-full flex items-end justify-center h-full">
                  <div 
                    className="w-full bg-charcoal rounded-2xl transition-all duration-700 group-hover:bg-primary group-hover:-translate-y-1"
                    style={{ height: item.height }}
                  >
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all bg-charcoal text-white text-[9px] py-1 px-2 rounded-lg font-black whitespace-nowrap z-10 shadow-xl">
                      {item.qty} items
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-black text-charcoal/40 uppercase tracking-tighter">{item.label}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Quick Action / AI Recommendation */}
        <button className="w-full bg-primary/10 border border-primary/20 rounded-[35px] p-6 flex items-center justify-between active:scale-[0.98] transition-all group">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-primary flex items-center justify-center text-white shadow-lg shadow-primary/30">
              <span className="material-symbols-outlined">auto_awesome</span>
            </div>
            <div className="text-left">
              <h4 className="font-bold text-charcoal text-sm italic">"Tăng 20% đơn hàng Nữ"</h4>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">Đề xuất tối ưu từ AI Stylist</p>
            </div>
          </div>
          <span className="material-symbols-outlined text-primary group-hover:translate-x-1 transition-transform">east</span>
        </button>
      </main>

      <BottomNav current={Screen.DASHBOARD} navigateTo={navigateTo} />
    </div>
  );
};

export default DashboardScreen;
