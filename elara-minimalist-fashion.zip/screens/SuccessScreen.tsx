
import React from 'react';
import { Screen } from '../types';

interface SuccessScreenProps {
  navigateTo: (screen: Screen) => void;
}

const SuccessScreen: React.FC<SuccessScreenProps> = ({ navigateTo }) => {
  return (
    <div className="min-h-screen bg-background-light flex flex-col">
      <header className="sticky top-0 z-10 bg-background-light/80 backdrop-blur-md px-4 py-4 flex items-center justify-between">
        <button onClick={() => navigateTo(Screen.HOME)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <span className="material-symbols-outlined text-charcoal">close</span>
        </button>
        <h1 className="text-charcoal text-base font-bold">Trạng thái đơn hàng</h1>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 flex flex-col items-center px-6 py-8 max-w-md mx-auto w-full">
        <div className="flex flex-col items-center mb-10 w-full text-center">
          <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mb-6 shadow-[0_0_40px_0_rgba(34,195,101,0.2)]">
            <span className="material-symbols-outlined text-white text-5xl" style={{ fontVariationSettings: "'wght' 600" }}>check</span>
          </div>
          <h2 className="text-charcoal text-3xl font-extrabold tracking-tight mb-2">Cảm ơn bạn!</h2>
          <p className="text-gray-500 text-base font-medium max-w-[280px]">
            Đơn hàng của bạn đã được xác nhận và đang được xử lý.
          </p>
        </div>

        <div className="w-full bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-gray-50 pb-4">
              <span className="text-gray-400 text-sm font-medium">Mã đơn hàng</span>
              <span className="text-charcoal text-sm font-bold">#ELR-772190</span>
            </div>
            <div className="flex justify-between items-center border-b border-gray-50 pb-4">
              <span className="text-gray-400 text-sm font-medium">Ngày đặt</span>
              <span className="text-charcoal text-sm font-bold">20/10/2024</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm font-medium">Giao hàng dự kiến</span>
              <span className="text-charcoal text-sm font-bold">Thứ Năm, 24/10</span>
            </div>
          </div>
        </div>

        <div className="w-full relative mb-10 overflow-hidden rounded-xl h-32 bg-gray-200 flex items-center justify-center">
          <img 
            src="https://picsum.photos/400/200?grayscale" 
            className="absolute inset-0 w-full h-full object-cover opacity-40" 
            alt="Delivery map"
          />
          <div className="relative z-10 flex items-center gap-3 bg-white/90 px-4 py-2 rounded-full shadow-lg border border-white/20">
            <span className="material-symbols-outlined text-green-500 text-sm">local_shipping</span>
            <span className="text-xs font-bold text-charcoal uppercase tracking-wider">Đang chuẩn bị hàng</span>
          </div>
        </div>

        <div className="w-full space-y-3 mt-auto">
          <button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 rounded-xl shadow-md transition-all active:scale-[0.98]">
            Theo dõi đơn hàng
          </button>
          <button 
            onClick={() => navigateTo(Screen.HOME)}
            className="w-full bg-gray-100 hover:bg-gray-200 text-charcoal font-bold py-4 rounded-xl transition-all"
          >
            Quay lại trang chủ
          </button>
        </div>
      </main>

      <nav className="sticky bottom-0 bg-white/80 backdrop-blur-md border-t border-gray-100 px-6 pb-8 pt-3 flex items-center justify-between">
        <button onClick={() => navigateTo(Screen.HOME)} className="flex flex-col items-center gap-1 text-gray-400">
          <span className="material-symbols-outlined">home</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Trang chủ</span>
        </button>
        <button onClick={() => navigateTo(Screen.LISTING)} className="flex flex-col items-center gap-1 text-gray-400">
          <span className="material-symbols-outlined">search</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Mua sắm</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-green-500">
          <span className="material-symbols-outlined fill-[1]">shopping_bag</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Đơn hàng</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-gray-400">
          <span className="material-symbols-outlined">favorite</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Đã lưu</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-gray-400">
          <span className="material-symbols-outlined">person</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Hồ sơ</span>
        </button>
      </nav>
    </div>
  );
};

export default SuccessScreen;
