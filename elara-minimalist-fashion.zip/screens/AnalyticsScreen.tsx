
import React from 'react';
import { Screen } from '../types';
import BottomNav from '../components/BottomNav';

interface AnalyticsScreenProps {
  navigateTo: (screen: Screen) => void;
}

const AnalyticsScreen: React.FC<AnalyticsScreenProps> = ({ navigateTo }) => {
  // Mock data for visualizations
  const categoryData = [
    { label: 'Nam', value: 45, height: '70%' },
    { label: 'Nữ', value: 62, height: '95%' },
    { label: 'Quần Tây', value: 28, height: '45%' },
    { label: 'Quần Short', value: 35, height: '55%' },
  ];

  const pieData = [
    { label: 'Trực tiếp', value: 40, color: '#e0775c', dashArray: '40 100' },
    { label: 'Mạng xã hội', value: 35, color: '#2c2c2c', dashArray: '35 100', offset: '-40' },
    { label: 'Khác', value: 25, color: '#f2efe9', dashArray: '25 100', offset: '-75' },
  ];

  return (
    <div className="min-h-screen bg-background-light pb-32">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 px-6 py-6 flex items-center gap-4">
        <button 
          onClick={() => navigateTo(Screen.DASHBOARD)}
          className="size-10 flex items-center justify-center rounded-full bg-background-light text-charcoal active:scale-90 transition-all"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h1 className="text-xl font-bold tracking-tight">Phân tích chi tiết</h1>
      </header>

      <main className="px-6 py-6 space-y-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Đơn hàng trung bình (AOV)</p>
              <h2 className="text-3xl font-black text-primary">$185.20</h2>
              <p className="text-[10px] text-green-600 font-bold mt-1 flex items-center gap-1">
                <span className="material-symbols-outlined text-sm">trending_up</span> +12% so với tháng trước
              </p>
            </div>
            <div className="size-14 rounded-2xl bg-primary/5 flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-3xl">shopping_cart_checkout</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-5 rounded-[32px] border border-gray-100 shadow-sm">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Tổng sản phẩm</p>
              <h3 className="text-2xl font-black text-charcoal">1,248</h3>
            </div>
            <div className="bg-white p-5 rounded-[32px] border border-gray-100 shadow-sm">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Doanh thu</p>
              <h3 className="text-2xl font-black text-charcoal">$42.5K</h3>
            </div>
          </div>
        </div>

        {/* Bar Chart Section */}
        <section className="bg-white p-6 rounded-[40px] border border-gray-100 shadow-sm">
          <h3 className="text-base font-bold mb-8 flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-sm">bar_chart</span>
            Số lượng sản phẩm theo danh mục
          </h3>
          <div className="flex items-end justify-between h-48 gap-4 px-2">
            {categoryData.map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-3 group">
                <div className="relative w-full flex items-end justify-center h-full">
                  <div 
                    className="w-8 md:w-10 bg-primary/20 rounded-t-xl transition-all duration-1000 ease-out group-hover:bg-primary"
                    style={{ height: item.height }}
                  >
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-charcoal text-white text-[10px] py-0.5 px-2 rounded-md font-bold">
                      {item.value}
                    </div>
                  </div>
                </div>
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter truncate w-full text-center">{item.label}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Pie Chart Section */}
        <section className="bg-white p-6 rounded-[40px] border border-gray-100 shadow-sm">
          <h3 className="text-base font-bold mb-8 flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-sm">pie_chart</span>
            Nguồn doanh thu
          </h3>
          <div className="flex items-center gap-8">
            <div className="relative size-32">
              <svg viewBox="0 0 32 32" className="size-full -rotate-90">
                <circle r="16" cx="16" cy="16" fill="transparent" stroke="#f2efe9" strokeWidth="32" />
                {pieData.map((item, idx) => (
                  <circle
                    key={idx}
                    r="16"
                    cx="16"
                    cy="16"
                    fill="transparent"
                    stroke={item.color}
                    strokeWidth="32"
                    strokeDasharray={item.dashArray}
                    strokeDashoffset={item.offset || '0'}
                    className="transition-all duration-1000 ease-in-out"
                  />
                ))}
              </svg>
              <div className="absolute inset-4 bg-white rounded-full border border-gray-50 flex items-center justify-center">
                <span className="text-[10px] font-black text-charcoal">TOP 3</span>
              </div>
            </div>
            <div className="flex-1 space-y-3">
              {pieData.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="size-2 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-xs font-bold text-gray-500">{item.label}</span>
                  </div>
                  <span className="text-xs font-black text-charcoal">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Additional Insight Card */}
        <section className="bg-primary p-6 rounded-[40px] text-white">
          <div className="flex items-center gap-4 mb-4">
            <div className="size-12 rounded-2xl bg-white/20 flex items-center justify-center">
              <span className="material-symbols-outlined">lightbulb</span>
            </div>
            <div>
              <h4 className="font-bold">Gợi ý tối ưu</h4>
              <p className="text-[10px] text-white/70 font-bold uppercase tracking-widest">Dựa trên dữ liệu thực tế</p>
            </div>
          </div>
          <p className="text-sm leading-relaxed mb-4">
            Doanh thu từ "Mạng xã hội" đang tăng trưởng 15% mỗi tuần. Hãy cân nhắc việc chạy thêm chiến dịch quảng cáo cho danh mục <b>Minimalist Linen</b>.
          </p>
          <button className="w-full py-3 bg-white text-primary rounded-2xl font-bold text-xs uppercase tracking-widest active:scale-[0.98] transition-all">
            Xem kế hoạch đề xuất
          </button>
        </section>
      </main>

      <BottomNav current={Screen.DASHBOARD} navigateTo={navigateTo} />
    </div>
  );
};

export default AnalyticsScreen;
