
import React, { useState } from 'react';
import { Screen, CartItem } from '../types';

interface CheckoutScreenProps {
  cart: CartItem[];
  navigateTo: (screen: Screen) => void;
}

const CheckoutScreen: React.FC<CheckoutScreenProps> = ({ cart, navigateTo }) => {
  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'wallet' | 'cod'>('card');
  const [promoCode, setPromoCode] = useState('');

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const shippingFee = shippingMethod === 'standard' ? (subtotal > 200 ? 0 : 15) : 35;
  const discount = promoCode.toUpperCase() === 'ELARA20' ? subtotal * 0.2 : 0;
  const total = subtotal + shippingFee - discount;

  return (
    <div className="min-h-screen bg-background-light flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100 px-6 py-4 flex items-center justify-between">
        <button onClick={() => navigateTo(Screen.CART)} className="size-10 flex items-center justify-center rounded-full bg-gray-50 text-charcoal shadow-sm active:scale-90 transition-all">
          <span className="material-symbols-outlined text-[22px]">arrow_back</span>
        </button>
        <h2 className="text-lg font-bold tracking-tight">Thanh toán</h2>
        <div className="size-10"></div>
      </header>

      <main className="flex-1 overflow-y-auto no-scrollbar pb-64 px-6 pt-6">
        {/* Step Indicator */}
        <div className="flex justify-between items-center mb-10 max-w-[280px] mx-auto">
          <div className="flex flex-col items-center gap-2">
            <div className="size-8 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">1</div>
            <span className="text-[10px] font-bold text-primary uppercase tracking-tighter">Địa chỉ</span>
          </div>
          <div className="h-[2px] flex-1 bg-primary mx-2 -mt-6"></div>
          <div className="flex flex-col items-center gap-2">
            <div className="size-8 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">2</div>
            <span className="text-[10px] font-bold text-primary uppercase tracking-tighter">Vận chuyển</span>
          </div>
          <div className="h-[2px] flex-1 bg-gray-200 mx-2 -mt-6"></div>
          <div className="flex flex-col items-center gap-2">
            <div className="size-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 text-xs font-bold">3</div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Hoàn tất</span>
          </div>
        </div>

        {/* Order Summary (Collapsed/Small) */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold">Tóm tắt đơn hàng</h3>
            <span className="text-xs text-gray-400">{cart.length} sản phẩm</span>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm space-y-3">
            {cart.map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <div className="size-12 rounded-lg bg-rich-beige bg-cover bg-center" style={{ backgroundImage: `url(${item.product.image})` }} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold truncate">{item.product.name}</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">{item.selectedSize} • Qty: {item.quantity}</p>
                </div>
                <p className="text-sm font-bold">${(item.product.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Shipping Address */}
        <section className="mb-8">
          <h3 className="text-base font-bold mb-4">Thông tin nhận hàng</h3>
          <div className="space-y-3">
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-300 text-lg">person</span>
              <input 
                className="w-full bg-white border-gray-100 rounded-xl text-sm pl-11 pr-4 py-3.5 focus:ring-primary focus:border-primary transition-all shadow-sm" 
                placeholder="Họ và tên người nhận" 
                defaultValue="Nguyễn Hùng" 
              />
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-300 text-lg">call</span>
              <input 
                className="w-full bg-white border-gray-100 rounded-xl text-sm pl-11 pr-4 py-3.5 focus:ring-primary focus:border-primary transition-all shadow-sm" 
                placeholder="Số điện thoại" 
                defaultValue="0908 123 456" 
              />
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-300 text-lg">location_on</span>
              <input 
                className="w-full bg-white border-gray-100 rounded-xl text-sm pl-11 pr-4 py-3.5 focus:ring-primary focus:border-primary transition-all shadow-sm" 
                placeholder="Địa chỉ cụ thể (Số nhà, đường...)" 
                defaultValue="123 Đường Lê Lợi, Quận 1, TP. Hồ Chí Minh" 
              />
            </div>
          </div>
        </section>

        {/* Shipping Method */}
        <section className="mb-8">
          <h3 className="text-base font-bold mb-4">Phương thức vận chuyển</h3>
          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={() => setShippingMethod('standard')}
              className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all bg-white ${shippingMethod === 'standard' ? 'border-primary' : 'border-transparent shadow-sm'}`}
            >
              <div className="flex items-center gap-3">
                <div className={`size-5 rounded-full border-2 flex items-center justify-center ${shippingMethod === 'standard' ? 'border-primary' : 'border-gray-200'}`}>
                  {shippingMethod === 'standard' && <div className="size-2.5 bg-primary rounded-full" />}
                </div>
                <div>
                  <p className="text-sm font-bold">Giao hàng Tiêu chuẩn</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">3-5 ngày làm việc</p>
                </div>
              </div>
              <p className="text-sm font-bold">{subtotal > 200 ? 'MIỄN PHÍ' : '$15.00'}</p>
            </button>

            <button 
              onClick={() => setShippingMethod('express')}
              className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all bg-white ${shippingMethod === 'express' ? 'border-primary' : 'border-transparent shadow-sm'}`}
            >
              <div className="flex items-center gap-3">
                <div className={`size-5 rounded-full border-2 flex items-center justify-center ${shippingMethod === 'express' ? 'border-primary' : 'border-gray-200'}`}>
                  {shippingMethod === 'express' && <div className="size-2.5 bg-primary rounded-full" />}
                </div>
                <div>
                  <p className="text-sm font-bold">Giao hàng Hỏa tốc</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">Trong vòng 24h</p>
                </div>
              </div>
              <p className="text-sm font-bold">$35.00</p>
            </button>
          </div>
        </section>

        {/* Voucher */}
        <section className="mb-8">
          <h3 className="text-base font-bold mb-4">Mã giảm giá</h3>
          <div className="flex gap-2">
            <input 
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              className="flex-1 bg-white border-gray-100 rounded-xl text-sm px-4 py-3 focus:ring-primary focus:border-primary shadow-sm" 
              placeholder="Nhập mã (Thử ELARA20)" 
            />
            <button className="bg-charcoal text-white px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-widest active:scale-95 transition-transform">
              Áp dụng
            </button>
          </div>
          {discount > 0 && <p className="text-xs text-green-600 font-bold mt-2 ml-1 flex items-center gap-1"><span className="material-symbols-outlined text-sm">check_circle</span> Đã áp dụng giảm giá 20%</p>}
        </section>

        {/* Payment Methods */}
        <section className="mb-12">
          <h3 className="text-base font-bold mb-4">Thanh toán bằng</h3>
          <div className="space-y-3">
            <button 
              onClick={() => setPaymentMethod('card')}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all bg-white ${paymentMethod === 'card' ? 'border-primary' : 'border-transparent shadow-sm'}`}
            >
              <div className="flex items-center gap-4">
                <div className="bg-gray-50 p-2 rounded-lg"><span className="material-symbols-outlined text-charcoal">credit_card</span></div>
                <p className="text-sm font-bold">Thẻ Tín dụng / Ghi nợ</p>
              </div>
              <div className={`size-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'card' ? 'border-primary' : 'border-gray-200'}`}>
                {paymentMethod === 'card' && <div className="size-2.5 bg-primary rounded-full" />}
              </div>
            </button>

            <button 
              onClick={() => setPaymentMethod('cod')}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all bg-white ${paymentMethod === 'cod' ? 'border-primary' : 'border-transparent shadow-sm'}`}
            >
              <div className="flex items-center gap-4">
                <div className="bg-gray-50 p-2 rounded-lg"><span className="material-symbols-outlined text-charcoal">local_shipping</span></div>
                <p className="text-sm font-bold">Thanh toán khi nhận hàng (COD)</p>
              </div>
              <div className={`size-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'cod' ? 'border-primary' : 'border-gray-200'}`}>
                {paymentMethod === 'cod' && <div className="size-2.5 bg-primary rounded-full" />}
              </div>
            </button>
          </div>
        </section>
      </main>

      {/* Footer CTA */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 pb-10 z-[60] shadow-[0_-10px_40px_rgba(0,0,0,0.04)] rounded-t-[32px]">
        <div className="max-w-md mx-auto">
          <div className="space-y-2 mb-6">
            <div className="flex justify-between items-center text-gray-400 text-sm font-medium">
              <span>Tạm tính</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-gray-400 text-sm font-medium">
              <span>Phí vận chuyển</span>
              <span className={shippingFee === 0 ? 'text-green-600' : ''}>{shippingFee === 0 ? 'MIỄN PHÍ' : `$${shippingFee.toFixed(2)}`}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between items-center text-green-600 text-sm font-bold">
                <span>Giảm giá</span>
                <span>-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="h-px bg-gray-50 my-2"></div>
            <div className="flex justify-between items-center">
              <span className="text-xl font-bold">Tổng tiền</span>
              <span className="text-2xl font-black text-primary">${total.toFixed(2)}</span>
            </div>
          </div>
          
          <button 
            onClick={() => navigateTo(Screen.SUCCESS)}
            className="w-full bg-primary hover:bg-[#d06b50] text-white font-bold py-4.5 rounded-2xl transition-all shadow-xl shadow-primary/20 active:scale-[0.98] flex items-center justify-center gap-3 uppercase tracking-widest text-sm"
          >
            <span>Đặt hàng ngay</span>
            <span className="material-symbols-outlined text-[20px]">verified</span>
          </button>
          <p className="text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-4">Cam kết bảo mật thông tin 100%</p>
        </div>
      </footer>
    </div>
  );
};

export default CheckoutScreen;
