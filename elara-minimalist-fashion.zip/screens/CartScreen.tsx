
import React, { useState } from 'react';
import { Screen, CartItem } from '../types';
import { PRODUCTS } from '../constants';

interface CartScreenProps {
  cart: CartItem[];
  wishlist: CartItem[];
  navigateTo: (screen: Screen) => void;
  updateQuantity: (index: number, delta: number) => void;
  removeFromCart: (index: number) => void;
  moveToWishlist: (index: number) => void;
  moveToCart: (index: number) => void;
  removeFromWishlist: (index: number) => void;
}

const CartScreen: React.FC<CartScreenProps> = ({ 
  cart, 
  wishlist, 
  navigateTo, 
  updateQuantity, 
  removeFromCart, 
  moveToWishlist, 
  moveToCart, 
  removeFromWishlist 
}) => {
  const [isGift, setIsGift] = useState(false);
  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const giftFee = isGift ? 5 : 0;
  const shipping = cart.length > 0 ? (subtotal > 200 ? 0 : 15) : 0;
  const total = subtotal + shipping + giftFee;

  const freeShippingThreshold = 200;
  const progress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div className="min-h-screen bg-background-light flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 flex items-center justify-between bg-white/80 px-6 py-6 backdrop-blur-xl border-b border-gray-100">
        <button 
          onClick={() => navigateTo(Screen.LISTING)}
          className="flex size-10 items-center justify-center rounded-full bg-background-light text-charcoal shadow-sm active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <div className="flex flex-col items-center">
          <h1 className="text-xl font-bold tracking-tight">Giỏ hàng</h1>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{cart.length} món đồ</p>
        </div>
        <button className="flex size-10 items-center justify-center rounded-full bg-background-light text-charcoal shadow-sm">
          <span className="material-symbols-outlined text-[20px]">share</span>
        </button>
      </header>

      <main className="no-scrollbar flex-1 overflow-y-auto px-6 pb-72">
        {/* Progress Tracker */}
        {cart.length > 0 && (
          <div className="mt-6 mb-8 bg-white p-5 rounded-[32px] border border-primary/5 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2">
                <span className={`material-symbols-outlined text-sm ${subtotal >= freeShippingThreshold ? 'text-green-500' : 'text-primary'}`}>
                  {subtotal >= freeShippingThreshold ? 'check_circle' : 'local_shipping'}
                </span>
                <p className="text-xs font-bold text-charcoal">
                  {subtotal >= freeShippingThreshold 
                    ? 'Bạn đã được miễn phí vận chuyển!' 
                    : `Mua thêm $${(freeShippingThreshold - subtotal).toFixed(2)} để được Freeship`}
                </p>
              </div>
              <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">{Math.round(progress)}%</span>
            </div>
            <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ease-out ${subtotal >= freeShippingThreshold ? 'bg-green-500' : 'bg-primary'}`} 
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[50vh] text-center">
            <div className="size-28 rounded-full bg-rich-beige flex items-center justify-center mb-6 shadow-inner">
              <span className="material-symbols-outlined text-5xl text-gray-300">shopping_cart</span>
            </div>
            <h2 className="text-2xl font-bold mb-2">Giỏ hàng trống</h2>
            <p className="text-sm text-gray-400 max-w-[240px] mb-8 leading-relaxed">Có vẻ như bạn chưa chọn được món đồ ưng ý. Hãy tiếp tục khám phá nhé!</p>
            <button 
              onClick={() => navigateTo(Screen.LISTING)} 
              className="bg-charcoal text-white px-10 py-4 rounded-2xl font-bold text-sm tracking-widest uppercase shadow-xl active:scale-95 transition-all"
            >
              Tiếp tục mua sắm
            </button>
          </div>
        ) : (
          <div className="space-y-6 pt-4">
            {cart.map((item, idx) => (
              <div key={`${item.product.id}-${idx}`} className="group relative flex gap-4 rounded-[32px] bg-white p-4 shadow-sm border border-gray-50 hover:shadow-md transition-all">
                <div 
                  className="h-32 w-28 shrink-0 overflow-hidden rounded-2xl bg-center bg-no-repeat bg-cover bg-rich-beige" 
                  style={{ backgroundImage: `url("${item.product.image}")` }}
                />
                <div className="flex flex-1 flex-col justify-between py-1">
                  <div>
                    <div className="flex items-start justify-between">
                      <h3 className="text-base font-bold leading-tight line-clamp-2 pr-2">{item.product.name}</h3>
                      <button 
                        onClick={() => removeFromCart(idx)}
                        className="text-gray-300 p-1 hover:text-red-500 transition-colors"
                      >
                        <span className="material-symbols-outlined text-[20px]">close</span>
                      </button>
                    </div>
                    <div className="mt-2 flex gap-2">
                      <div className="px-2 py-1 bg-background-light rounded-lg text-[10px] font-bold text-gray-400 uppercase border border-gray-50">{item.selectedSize}</div>
                      <div className="px-2 py-1 bg-background-light rounded-lg text-[10px] font-bold text-gray-400 uppercase border border-gray-50">{item.selectedColor}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-lg font-bold text-primary">${item.product.price.toFixed(2)}</p>
                    <div className="flex items-center gap-3 rounded-2xl bg-background-light p-1 border border-gray-50">
                      <button 
                        onClick={() => updateQuantity(idx, -1)}
                        className="flex h-8 w-8 items-center justify-center rounded-xl bg-white hover:bg-primary hover:text-white transition-all shadow-sm active:scale-90"
                      >
                        <span className="material-symbols-outlined text-sm">remove</span>
                      </button>
                      <span className="w-4 text-center text-sm font-bold">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(idx, 1)}
                        className="flex h-8 w-8 items-center justify-center rounded-xl bg-white hover:bg-primary hover:text-white transition-all shadow-sm active:scale-90"
                      >
                        <span className="material-symbols-outlined text-sm">add</span>
                      </button>
                    </div>
                  </div>
                </div>
                {/* Save for Later shortcut */}
                <button 
                  onClick={() => moveToWishlist(idx)}
                  className="absolute -right-2 top-1/2 -translate-y-1/2 size-8 bg-white rounded-full border border-gray-100 shadow-sm flex items-center justify-center text-gray-300 hover:text-primary transition-all active:scale-95"
                  title="Lưu mua sau"
                >
                  <span className="material-symbols-outlined text-sm">bookmark</span>
                </button>
              </div>
            ))}

            {/* Gift Toggle */}
            <div className="bg-white rounded-[32px] p-5 flex items-center justify-between border border-gray-50 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="size-12 rounded-2xl bg-primary/5 flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined">featured_seasonal</span>
                </div>
                <div>
                  <p className="text-sm font-bold">Gói quà tặng cao cấp</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">Thêm $5.00 cho mỗi đơn hàng</p>
                </div>
              </div>
              <button 
                onClick={() => setIsGift(!isGift)}
                className={`w-12 h-6 rounded-full transition-all duration-300 relative ${isGift ? 'bg-primary' : 'bg-gray-200'}`}
              >
                <div className={`absolute top-1 size-4 bg-white rounded-full shadow-sm transition-all duration-300 ${isGift ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
          </div>
        )}

        {/* Recommended Items */}
        {cart.length > 0 && (
          <section className="mt-12">
            <h3 className="text-base font-bold mb-6 flex items-center gap-2">
              <span className="material-symbols-outlined text-sm text-primary">auto_awesome</span>
              Có thể bạn sẽ thích
            </h3>
            <div className="flex overflow-x-auto no-scrollbar gap-4 -mx-6 px-6">
              {PRODUCTS.filter(p => !cart.find(c => c.product.id === p.id)).slice(0, 3).map((product) => (
                <div key={product.id} className="min-w-[140px] flex flex-col gap-3 group">
                  <div className="aspect-[4/5] bg-rich-beige rounded-2xl overflow-hidden relative">
                    <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110" style={{ backgroundImage: `url(${product.image})` }} />
                    <button className="absolute bottom-2 right-2 size-8 bg-white/90 backdrop-blur rounded-xl flex items-center justify-center shadow-sm">
                      <span className="material-symbols-outlined text-sm">add</span>
                    </button>
                  </div>
                  <div>
                    <p className="text-[11px] font-bold truncate">{product.name}</p>
                    <p className="text-[11px] font-black text-primary">${product.price.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Saved for Later Section */}
        {wishlist.length > 0 && (
          <section className="mt-12 pb-12">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold tracking-tight">Đã lưu để mua sau</h3>
              <span className="px-3 py-1 bg-white border border-gray-100 text-[10px] font-bold rounded-full text-gray-400 uppercase tracking-widest">{wishlist.length}</span>
            </div>
            <div className="space-y-4">
              {wishlist.map((item, idx) => (
                <div key={`saved-${idx}`} className="flex items-center gap-4 bg-white/50 p-3 rounded-[24px] border border-dashed border-gray-200 group transition-all hover:bg-white">
                  <div 
                    className="h-20 w-16 shrink-0 rounded-xl bg-center bg-cover bg-rich-beige opacity-80" 
                    style={{ backgroundImage: `url("${item.product.image}")` }}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-bold leading-tight">{item.product.name}</p>
                    <p className="text-xs text-gray-400 mt-0.5">${item.product.price.toFixed(2)} • Size {item.selectedSize}</p>
                    <div className="flex gap-4 mt-2">
                      <button 
                        onClick={() => moveToCart(idx)}
                        className="text-[10px] font-bold text-primary uppercase tracking-widest underline decoration-2 underline-offset-4"
                      >
                        Thêm vào túi
                      </button>
                      <button 
                        onClick={() => removeFromWishlist(idx)}
                        className="text-[10px] font-bold text-gray-400 uppercase tracking-widest"
                      >
                        Xóa bỏ
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Checkout Footer */}
      {cart.length > 0 && (
        <footer className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-2xl p-6 pb-10 shadow-[0_-20px_60px_rgba(0,0,0,0.06)] border-t border-gray-100 rounded-t-[48px]">
          <div className="max-w-md mx-auto">
            <div className="mb-6 space-y-3 px-2">
              <div className="flex justify-between text-sm">
                <p className="text-gray-400 font-medium">Tạm tính</p>
                <p className="font-bold text-charcoal">${subtotal.toFixed(2)}</p>
              </div>
              <div className="flex justify-between text-sm">
                <p className="text-gray-400 font-medium">Phí giao hàng</p>
                <p className={`font-bold ${shipping === 0 ? 'text-green-600' : 'text-charcoal'}`}>
                  {shipping === 0 ? 'MIỄN PHÍ' : `$${shipping.toFixed(2)}`}
                </p>
              </div>
              {isGift && (
                <div className="flex justify-between text-sm">
                  <p className="text-gray-400 font-medium">Phí gói quà</p>
                  <p className="font-bold text-charcoal">$5.00</p>
                </div>
              )}
              <div className="my-4 h-px bg-gray-50"></div>
              <div className="flex justify-between items-center">
                <p className="text-xl font-bold">Tổng cộng</p>
                <div className="text-right">
                  <p className="text-3xl font-black text-primary tracking-tight">${total.toFixed(2)}</p>
                  <p className="text-[10px] uppercase tracking-wider text-gray-300 font-bold">Giá đã bao gồm VAT</p>
                </div>
              </div>
            </div>
            <button 
              onClick={() => navigateTo(Screen.CHECKOUT)}
              className="flex w-full h-16 items-center justify-center gap-3 rounded-[24px] bg-charcoal text-white shadow-2xl transition-all active:scale-[0.98] hover:bg-charcoal/90 group"
            >
              <span className="font-bold tracking-[0.2em] uppercase text-sm">Tiến hành đặt hàng</span>
              <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
            </button>
          </div>
        </footer>
      )}
    </div>
  );
};

export default CartScreen;
