
import React, { useState } from 'react';
import { Screen, Product } from '../types';
import { PRODUCTS } from '../constants';
import BottomNav from '../components/BottomNav';

interface ListingScreenProps {
  navigateTo: (screen: Screen, product?: Product) => void;
}

const ListingScreen: React.FC<ListingScreenProps> = ({ navigateTo }) => {
  const [activeTab, setActiveTab] = useState<'MEN' | 'WOMEN'>('MEN');

  return (
    <div className="min-h-screen bg-background-light flex flex-col">
      <header className="sticky top-0 z-50 bg-background-light/80 backdrop-blur-md border-b border-gray-100">
        <div className="flex items-center justify-between px-6 py-4">
          <button className="flex items-center justify-center p-1" onClick={() => navigateTo(Screen.HOME)}>
            <span className="material-symbols-outlined text-2xl">arrow_back</span>
          </button>
          <h1 className="text-xl font-bold tracking-tight uppercase">Cửa hàng</h1>
          <button 
            onClick={() => navigateTo(Screen.CART)}
            className="flex items-center justify-center p-1 relative"
          >
            <span className="material-symbols-outlined text-2xl">shopping_bag</span>
            <span className="absolute top-0 right-0 h-2.5 w-2.5 bg-primary rounded-full border-2 border-background-light"></span>
          </button>
        </div>

        <div className="px-6 pb-2">
          <div className="flex bg-gray-100 rounded-xl p-1">
            <button 
              onClick={() => setActiveTab('MEN')}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'MEN' ? 'bg-white text-primary shadow-sm' : 'text-gray-400'}`}
            >
              NAM
            </button>
            <button 
              onClick={() => setActiveTab('WOMEN')}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${activeTab === 'WOMEN' ? 'bg-white text-primary shadow-sm' : 'text-gray-400'}`}
            >
              NỮ
            </button>
          </div>
        </div>

        <div className="flex items-center justify-start px-6 py-3 overflow-x-auto gap-3 no-scrollbar">
          <button className="flex shrink-0 items-center gap-2 px-4 py-2 rounded-full border border-gray-200 bg-white">
            <span className="material-symbols-outlined text-sm">tune</span>
            <span className="text-xs font-semibold tracking-wide uppercase">Lọc</span>
          </button>
          <button className="flex shrink-0 items-center gap-2 px-4 py-2 rounded-full border border-primary bg-primary/5 text-primary">
            <span className="text-xs font-semibold tracking-wide uppercase">Quần Short</span>
            <span className="material-symbols-outlined text-[10px] font-bold">close</span>
          </button>
          <button className="flex shrink-0 items-center gap-2 px-4 py-2 rounded-full border border-gray-200 bg-white">
            <span className="text-xs font-semibold tracking-wide uppercase">Giá: Thấp đến Cao</span>
            <span className="material-symbols-outlined text-sm">keyboard_arrow_down</span>
          </button>
        </div>
      </header>

      <main className="p-4 mb-24 overflow-y-auto">
        <div className="grid grid-cols-2 gap-4">
          {PRODUCTS.map((product, idx) => (
            <button 
              key={product.id} 
              className={`flex flex-col gap-3 group text-left ${idx === 0 ? 'col-span-2' : ''}`}
              onClick={() => navigateTo(Screen.DETAIL, product)}
            >
              <div className={`relative w-full ${idx === 0 ? 'aspect-[4/5]' : 'aspect-[3/4]'} bg-rich-beige rounded-xl overflow-hidden shadow-sm`}>
                <div 
                  className="w-full h-full bg-center bg-cover transition-transform duration-700 group-hover:scale-105" 
                  style={{ backgroundImage: `url("${product.image}")` }}
                />
                <div className="absolute top-4 right-4 bg-white/90 p-2 rounded-full backdrop-blur-sm z-10">
                  <span className="material-symbols-outlined text-xl text-charcoal">favorite</span>
                </div>
                {product.isBestSeller && (
                  <div className="absolute bottom-4 left-4">
                    <span className="bg-green-700 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">Bền vững</span>
                  </div>
                )}
              </div>
              <div className="flex justify-between items-start px-1">
                <div>
                  <h3 className={`${idx === 0 ? 'text-lg font-bold' : 'text-sm font-bold'} leading-tight`}>{product.name}</h3>
                  <p className="text-xs text-gray-500">Trắng tự nhiên • Form vừa</p>
                  {product.isNewArrival && <span className="text-[9px] font-bold text-primary uppercase tracking-widest mt-1 block">Hàng mới về</span>}
                </div>
                <p className={`${idx === 0 ? 'text-lg font-bold' : 'text-xs font-bold'} text-primary`}>{product.price.toFixed(2)} $</p>
              </div>
            </button>
          ))}
        </div>
      </main>

      <BottomNav current={Screen.LISTING} navigateTo={navigateTo} />
    </div>
  );
};

export default ListingScreen;
