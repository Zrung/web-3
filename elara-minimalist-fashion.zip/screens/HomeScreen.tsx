
import React, { useState, useEffect } from 'react';
import { Screen, Product } from '../types';
import { CATEGORIES, PRODUCTS } from '../constants';
import BottomNav from '../components/BottomNav';

interface HomeScreenProps {
  navigateTo: (screen: Screen, product?: Product) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ navigateTo }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "Bộ Sưu Tập Mùa Thu",
      subtitle: "Hè 2024",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDoXWw2ZIKn-wOtyhcIVw2AjQm6QZoOZ6VyYssM4lQsDDM5qLkl1cx7p8NzqN-spP1PYYBALx5I68-WT-QB7RiKIxD87iknj2mFKuIoTcaRmenwTsxxe-DhOohXBb9v9pQAUhKF2IaYDvNBEK2Dx-KmHwUATlgUjfio_3AdCF9Qtplg3AUrZkStuMDrqekz9w7llV6PRM2UtApxKOuDg00BT_YGyU6XI82Djlzo6IzvX33QI_dIsz24UYRYf4YKLIkOzFA9n0zJnC54"
    },
    {
      title: "Đồ Len Thiết Yếu",
      subtitle: "Bộ Sưu Tập Mới",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAB4NKhiOKb7OuvrSrTpxUYrEeTF6LLWXWHq-aJ4RUY65jl8AhGOxT_UudM7_h1XEOqXUeysLD0dvF19c_kdV39RLDLeuUCgE_zCW2Mp0jKOpJlm8foFhbrgzTl8I1n-wmlFBRrT7Dthdhq5-eSGQQvYJG6_5W2V1zjnQIMWKFlxdAcVBxVRIKxtL1yYfpB_l9feehHG-oZkQgBtCuH9Od-ij_W0jZczBt0wgDjpOApsGnFEcJshX46blqXq61S45OJ15oez3DUeMdU"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background-light/80 backdrop-blur-md px-4 py-4 flex items-center justify-between">
        <button className="flex items-center justify-center w-10 h-10">
          <span className="material-symbols-outlined text-[24px]">search</span>
        </button>
        <h1 className="text-xl font-bold tracking-[0.2em] uppercase">Elara</h1>
        <button 
          onClick={() => navigateTo(Screen.CART)}
          className="flex items-center justify-center w-10 h-10 relative"
        >
          <span className="material-symbols-outlined text-[24px]">shopping_bag</span>
          <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full"></span>
        </button>
      </header>

      {/* Hero Carousel */}
      <section className="px-4 py-2">
        <div className="relative w-full aspect-[16/10] rounded-xl overflow-hidden shadow-sm bg-gray-100">
          <div 
            className="flex h-full transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {slides.map((slide, index) => (
              <div key={index} className="relative min-w-full h-full">
                <div 
                  className="absolute inset-0 bg-cover bg-center" 
                  style={{ backgroundImage: `url('${slide.image}')` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 flex flex-col items-start gap-2">
                  <div>
                    <span className="text-white/80 text-[10px] tracking-[0.3em] uppercase mb-1 block">{slide.subtitle}</span>
                    <h2 className="text-white text-2xl font-bold leading-tight">{slide.title}</h2>
                  </div>
                  <button 
                    onClick={() => navigateTo(Screen.LISTING)}
                    className="bg-white text-charcoal px-4 py-2 rounded-lg font-bold text-[10px] tracking-widest uppercase hover:bg-white/90 transition-colors mt-1"
                  >
                    Mua ngay
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          {/* Pagination Dots */}
          <div className="absolute bottom-3 right-6 flex gap-1.5">
            {slides.map((_, index) => (
              <button 
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-1 rounded-full transition-all duration-300 ${currentSlide === index ? 'w-6 bg-white' : 'w-2 bg-white/40'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8">
        <div className="flex overflow-x-auto no-scrollbar gap-6 px-4">
          {CATEGORIES.map((cat, idx) => (
            <button key={idx} className="flex flex-col items-center gap-3 shrink-0" onClick={() => navigateTo(Screen.LISTING)}>
              <div className={`w-16 h-16 rounded-full border ${idx === 2 ? 'border-2 border-primary' : 'border-gray-200'} p-1`}>
                <div 
                  className="w-full h-full rounded-full bg-cover bg-center" 
                  style={{ backgroundImage: `url('${cat.image}')` }}
                />
              </div>
              <span className={`text-[10px] font-bold tracking-widest uppercase ${idx === 2 ? '' : 'opacity-60'}`}>{cat.name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="py-4">
        <div className="flex items-center justify-between px-4 mb-6">
          <h3 className="text-xl font-bold tracking-tight">Xu hướng hiện nay</h3>
          <button onClick={() => navigateTo(Screen.LISTING)} className="text-primary text-xs font-bold tracking-widest uppercase">Xem tất cả</button>
        </div>
        <div className="flex overflow-x-auto no-scrollbar gap-4 px-4">
          {PRODUCTS.slice(0, 3).map((product) => (
            <button 
              key={product.id} 
              className="min-w-[180px] flex flex-col gap-3 group text-left"
              onClick={() => navigateTo(Screen.DETAIL, product)}
            >
              <div className="relative aspect-[3/4] bg-rich-beige rounded-lg overflow-hidden">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105" 
                  style={{ backgroundImage: `url('${product.image}')` }}
                />
                <div className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">favorite</span>
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <p className="text-sm font-medium">{product.name}</p>
                <p className="text-primary font-bold">{product.price.toFixed(2)} $</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Footer Branding */}
      <section className="mt-12 mb-8 px-8 text-center">
        <div className="h-[1px] w-12 bg-gray-300 mx-auto mb-6"></div>
        <p className="text-xs font-bold tracking-[0.2em] uppercase opacity-50 mb-2">Từ năm 2021</p>
        <p className="text-lg italic font-light leading-relaxed">"Phong cách tối giản tinh tế cho cá nhân hiện đại."</p>
      </section>

      <BottomNav current={Screen.HOME} navigateTo={navigateTo} />
    </div>
  );
};

export default HomeScreen;
