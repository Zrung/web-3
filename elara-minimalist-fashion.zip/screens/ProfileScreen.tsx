
import React, { useState } from 'react';
import { Screen } from '../types';
import BottomNav from '../components/BottomNav';

interface ProfileScreenProps {
  navigateTo: (screen: Screen) => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ navigateTo }) => {
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const menuItems = [
    { icon: 'shopping_bag', label: 'Đơn hàng của tôi', badge: '2 đang giao' },
    { icon: 'favorite', label: 'Danh sách yêu thích', badge: '12 món' },
    { icon: 'location_on', label: 'Địa chỉ nhận hàng', badge: null },
    { icon: 'payments', label: 'Phương thức thanh toán', badge: 'Visa ***42' },
    { icon: 'confirmation_number', label: 'Mã giảm giá', badge: '3 mới' },
    { icon: 'notifications', label: 'Thông báo', badge: null },
    { icon: 'help', label: 'Hỗ trợ khách hàng', badge: null },
    { icon: 'privacy_tip', label: 'Quyền riêng tư & Bảo mật', badge: null },
  ];

  const handleLogout = () => {
    // Thực hiện logic đăng xuất ở đây (ví dụ: xóa token)
    setShowLogoutModal(false);
    navigateTo(Screen.HOME);
  };

  return (
    <div className="min-h-screen bg-background-light pb-32">
      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
          <div 
            className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm transition-opacity"
            onClick={() => setShowLogoutModal(false)}
          />
          <div className="relative w-full max-w-sm bg-white rounded-[40px] p-8 shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="flex flex-col items-center text-center">
              <div className="size-20 rounded-full bg-red-50 flex items-center justify-center text-red-500 mb-6">
                <span className="material-symbols-outlined text-4xl">logout</span>
              </div>
              <h3 className="text-2xl font-black text-charcoal mb-2">Đăng xuất?</h3>
              <p className="text-sm text-gray-500 mb-8 leading-relaxed px-4">
                Bạn có chắc chắn muốn đăng xuất khỏi tài khoản <b>Nguyễn Hùng</b> không?
              </p>
              <div className="w-full space-y-3">
                <button 
                  onClick={handleLogout}
                  className="w-full py-4 bg-red-500 text-white rounded-2xl font-bold text-sm uppercase tracking-widest shadow-lg shadow-red-500/20 active:scale-[0.98] transition-all"
                >
                  Xác nhận đăng xuất
                </button>
                <button 
                  onClick={() => setShowLogoutModal(false)}
                  className="w-full py-4 bg-gray-50 text-gray-400 rounded-2xl font-bold text-sm uppercase tracking-widest active:scale-[0.98] transition-all"
                >
                  Hủy bỏ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="px-6 py-6 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight">Hồ sơ</h1>
        <button className="p-2 rounded-full bg-white shadow-sm hover:bg-gray-50 transition-colors">
          <span className="material-symbols-outlined text-charcoal">settings</span>
        </button>
      </header>

      <main className="px-6">
        {/* Profile Card */}
        <section className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 mb-8">
          <div className="flex items-center gap-5">
            <div className="relative">
              <div 
                className="w-20 h-20 rounded-2xl bg-cover bg-center border-4 border-rich-beige"
                style={{ backgroundImage: `url('https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200')` }}
              />
              <div className="absolute -bottom-1 -right-1 bg-primary text-white p-1 rounded-lg border-2 border-white">
                <span className="material-symbols-outlined text-xs">edit</span>
              </div>
            </div>
            <div className="flex flex-1 flex-col">
              <h2 className="text-xl font-bold text-charcoal leading-none mb-1">Nguyễn Hùng</h2>
              <p className="text-sm text-gray-500 mb-2">hung.nguyen@elaramail.com</p>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-rich-beige rounded-full w-fit">
                <span className="material-symbols-outlined text-[14px] text-primary fill-[1]">verified</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-primary">Thành viên Bạch kim</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-gray-50">
            <div className="flex flex-col items-center">
              <span className="text-lg font-bold">24</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">Đơn hàng</span>
            </div>
            <div className="flex flex-col items-center border-x border-gray-50">
              <span className="text-lg font-bold">12</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">Yêu thích</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-lg font-bold">3</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">Voucher</span>
            </div>
          </div>
        </section>

        {/* Menu Items */}
        <section className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm">
          {menuItems.map((item, idx) => (
            <button 
              key={idx}
              className={`w-full flex items-center justify-between px-6 py-4.5 hover:bg-gray-50 transition-colors ${idx !== menuItems.length - 1 ? 'border-b border-gray-50' : ''}`}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-background-light flex items-center justify-center text-gray-500">
                  <span className="material-symbols-outlined">{item.icon}</span>
                </div>
                <span className="font-semibold text-charcoal">{item.label}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <span className="text-[10px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
                <span className="material-symbols-outlined text-gray-300">chevron_right</span>
              </div>
            </button>
          ))}
        </section>

        {/* Account Management */}
        <section className="mt-8 space-y-3">
          <button 
            onClick={() => setShowLogoutModal(true)}
            className="w-full flex items-center justify-center gap-2 py-5 rounded-3xl bg-red-50 text-red-600 font-black hover:bg-red-100 active:scale-[0.98] transition-all uppercase text-xs tracking-[0.1em]"
          >
            <span className="material-symbols-outlined text-[22px]">logout</span>
            Đăng xuất tài khoản
          </button>
          <p className="text-center text-[10px] font-bold text-gray-300 uppercase tracking-[0.2em] py-4">
            Elara Fashion App v2.4.0
          </p>
        </section>
      </main>

      <BottomNav current={Screen.PROFILE} navigateTo={navigateTo} />
    </div>
  );
};

export default ProfileScreen;
